OK_FORMAT = True

test = {   'name': 'q6',
    'points': [0],
    'suites': [   {   'cases': [   {   'code': ">>> assert np.ndim(q6a) == 0 and float(q6a) >= 0, 'q6a is a distance in meters (zero or positive)'\n"
                                               ">>> assert len(q6b) == 2 and all((float(v) == int(v) for v in q6b)), 'q6b is two whole numbers in parentheses, e.g. (14, 3)'\n"
                                               ">>> assert isinstance(q6c, (bool, np.bool_)), 'q6c is True or False'\n"
                                               ">>> assert q6d in ['a', 'b', 'c', 'd'], 'q6d is one letter in quotes'\n",
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
