OK_FORMAT = True

test = {   'name': 'q1',
    'points': [0],
    'suites': [   {   'cases': [{'code': ">>> assert np.ndim(q1_N) == 0 and np.ndim(q1_D_m) == 0, 'each answer is one number'\n", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
