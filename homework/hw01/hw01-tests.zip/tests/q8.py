OK_FORMAT = True

test = {   'name': 'q8',
    'points': [0],
    'suites': [   {   'cases': [   {   'code': ">>> assert np.ndim(q8a) == 0 and np.isfinite(float(q8a)), 'q8a is a number in dB'\n"
                                               ">>> assert len(q8b) == 3 and all((isinstance(v, (bool, np.bool_)) for v in q8b)), 'q8b is a list of three True/False values'\n",
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
