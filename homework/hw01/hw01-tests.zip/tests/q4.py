OK_FORMAT = True

test = {   'name': 'q4',
    'points': [0],
    'suites': [   {   'cases': [   {   'code': ">>> assert np.ndim(q4a) == 0 and np.ndim(q4b) == 0, 'each answer is one number'\n"
                                               ">>> assert float(q4b) > 0, 'q4b is how much weaker: a positive number of dB'\n",
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
