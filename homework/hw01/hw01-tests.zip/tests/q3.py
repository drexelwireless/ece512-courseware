OK_FORMAT = True

test = {   'name': 'q3',
    'points': [0],
    'suites': [   {   'cases': [{'code': ">>> assert q3 in ['a', 'b', 'c', 'd'], 'q3 is one letter in quotes'\n", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
