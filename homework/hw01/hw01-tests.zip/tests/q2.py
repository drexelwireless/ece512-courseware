OK_FORMAT = True

test = {   'name': 'q2',
    'points': [0],
    'suites': [   {   'cases': [   {   'code': ">>> assert float(q2a) == int(q2a) and float(q2b) == int(q2b), 'q2a and q2b are whole numbers'\n"
                                               ">>> assert q2c in ['a', 'b', 'c', 'd'], 'q2c is one letter in quotes'\n",
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
