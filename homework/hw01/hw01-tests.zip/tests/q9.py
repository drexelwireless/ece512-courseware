OK_FORMAT = True

test = {   'name': 'q9',
    'points': 1,
    'suites': [   {   'cases': [{'code': ">>> assert isinstance(reflection, str) and len(reflection.split()) >= 40, 'write at least 40 words'\n", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
