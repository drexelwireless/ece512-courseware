OK_FORMAT = True

test = {   'name': 'q7',
    'points': [0],
    'suites': [   {   'cases': [{'code': ">>> assert q7 in ['a', 'b', 'c', 'd'], 'q7 is one letter in quotes'\n", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
